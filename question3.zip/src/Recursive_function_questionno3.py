import turtle
import math

def draw_recursive_edge(length, depth):
    """Recursively draw a single edge with indentations."""
    if depth == 0:
        turtle.forward(length)
        return
    
    # Dividing edge into three parts
    new_length = length / 3
    
    # First segment
    draw_recursive_edge(new_length, depth - 1)
    
    # First side 
    turtle.right(60)
    draw_recursive_edge(new_length, depth - 1)
    
    # Second side 
    turtle.left(120)
    draw_recursive_edge(new_length, depth - 1)
    
    # Final segment
    turtle.right(60)
    draw_recursive_edge(new_length, depth - 1)

def draw_pattern(sides, length, depth):
    """Draw the complete pattern with specified number of sides."""
    # calulating internal angle of the polygon 
    angle = 360 / sides
    
    for _ in range(sides):
        draw_recursive_edge(length, depth)
        turtle.right(angle)

def main():
    
    sides = int(input("Enter the number of sides: "))
    length = float(input("Enter the side length: "))
    depth = int(input("Enter the recursion depth: "))
    
    # Seting-up turtle
    turtle.speed(0) 
    turtle.penup()
    
    # Center the pattern
    turtle.goto(-length/2, length/2)
    turtle.pendown()
    
    # Draw the pattern
    draw_pattern(sides, length, depth)
    
    
    turtle.done()   #complete the turtle section 

if __name__ == "__main__":
    main()